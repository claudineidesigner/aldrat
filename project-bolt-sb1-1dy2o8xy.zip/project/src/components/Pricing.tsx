import React from 'react';
import SectionTitle from './SectionTitle';
import Button from './Button';
import { Check, X } from 'lucide-react';

interface PricingFeature {
  name: string;
  included: boolean;
}

interface PricingPlanProps {
  title: string;
  price: string;
  features: PricingFeature[];
  popular?: boolean;
}

const PricingPlan: React.FC<PricingPlanProps> = ({ 
  title, 
  price, 
  features,
  popular = false
}) => {
  return (
    <div className={`
      bg-white rounded-xl overflow-hidden transition-all
      ${popular ? 'shadow-xl border-2 border-blue-500 scale-105 z-10' : 'shadow-md hover:shadow-lg'}
    `}>
      {popular && (
        <div className="bg-blue-500 text-white text-center py-2 font-medium">
          Mais Popular
        </div>
      )}
      <div className="p-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">{title}</h3>
        <div className="mb-6">
          <span className="text-4xl font-bold text-gray-900">R$ {price}</span>
          <span className="text-gray-600">/mês</span>
        </div>
        <ul className="space-y-4 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              {feature.included ? (
                <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
              ) : (
                <X className="h-5 w-5 text-gray-400 mr-3 mt-0.5 flex-shrink-0" />
              )}
              <span className={feature.included ? "text-gray-700" : "text-gray-400"}>
                {feature.name}
              </span>
            </li>
          ))}
        </ul>
        <Button 
          href={`#contato?plan=${encodeURIComponent(title)}`}
          variant={popular ? "primary" : "outline"}
          className="w-full"
        >
          Começar Agora
        </Button>
      </div>
    </div>
  );
};

const Pricing: React.FC = () => {
  const plans = [
    {
      title: "Essencial",
      price: "397",
      popular: false,
      features: [
        { name: "Configuração Básica", included: true },
        { name: "5 postagens por mês", included: true },
        { name: "Relatório mensal", included: true },
        { name: "SEO Local", included: false },
        { name: "Gestão de Avaliações", included: false },
        { name: "Publicações Diárias", included: false },
        { name: "Monitoramento Avançado", included: false },
        { name: "Chat G4", included: false }
      ]
    },
    {
      title: "Pro",
      price: "1.299",
      popular: true,
      features: [
        { name: "Configuração Básica", included: true },
        { name: "5 postagens por mês", included: true },
        { name: "Relatório mensal", included: true },
        { name: "SEO Local", included: true },
        { name: "Gestão de Avaliações", included: true },
        { name: "Publicações Diárias", included: false },
        { name: "Monitoramento Avançado", included: false },
        { name: "Chat G4", included: false }
      ]
    },
    {
      title: "Premium",
      price: "1.999",
      popular: false,
      features: [
        { name: "Configuração Básica", included: true },
        { name: "5 postagens por mês", included: true },
        { name: "Relatório mensal", included: true },
        { name: "SEO Local", included: true },
        { name: "Gestão de Avaliações", included: true },
        { name: "Publicações Diárias", included: true },
        { name: "Monitoramento Avançado", included: true },
        { name: "Chat G4", included: true }
      ]
    }
  ];

  return (
    <section id="pacotes" className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle 
          title="Planos de Crescimento Para o Seu Negócio" 
          subtitle="Escolha o pacote ideal e comece hoje a transformar sua presença no Google em resultados reais."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <PricingPlan 
              key={index}
              title={plan.title}
              price={plan.price}
              features={plan.features}
              popular={plan.popular}
            />
          ))}
        </div>
        
        <p className="text-center text-gray-600 mt-12 max-w-2xl mx-auto">
          "Cada cliente que procura por você no Google e não te encontra é uma venda perdida para a concorrência."
        </p>
      </div>
    </section>
  );
};

export default Pricing;