import React from 'react';
import Button from './Button';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-blue-50 to-blue-100 pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 mb-10 md:mb-0">
            <div className="max-w-xl">
             
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-4">
                Quem procura seu produto ou serviço, te encontra no Google?
              </h1>
              <p className="text-lg md:text-xl text-gray-700 mb-8">
                Garanta que sim! Otimizamos o Perfil da Empresa no Google para transformar buscas em ligações, visitas e mais vendas.
              </p>
              <Button href="#contato">Quero Meu Perfil Otimizado!</Button>
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-green-100 rounded-full opacity-60 animate-pulse"></div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-blue-100 rounded-full opacity-60 animate-pulse"></div>
              <img 
                src="https://nextlevelcompany.com.br/wp-content/webp-express/webp-images/uploads/2025/02/1.jpg.webp" 
                alt="Otimização do Perfil da empresa no Google" 
                className="relative z-10 rounded-xl shadow-xl w-full object-cover h-auto"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
};

export default Hero;