import React from 'react';
import { CheckCircle, Settings, BarChart2, RefreshCw } from 'lucide-react';
import SectionTitle from './SectionTitle';

interface ServiceItemProps {
  title: string;
  items: string[];
  icon: React.ReactNode;
}

const ServiceItem: React.FC<ServiceItemProps> = ({ title, items, icon }) => {
  return (
    <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
      <div className="flex items-center mb-6">
        <div className="p-3 bg-blue-100 rounded-lg mr-4">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-gray-900">{title}</h3>
      </div>
      <ul className="space-y-3">
        {items.map((item, index) => (
          <li key={index} className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
            <span className="text-gray-600">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

const Services: React.FC = () => {
  const services = [
    {
      title: "1. Configuração Inicial",
      icon: <Settings className="h-6 w-6 text-blue-600" />,
      items: [
        "Criação e verificação do perfil",
        "Preenchimento de informações: nome, endereço, telefone, site e horários",
        "Seleção de categorias e definição de área de atuação",
        "Descrição otimizada com palavras-chave locais",
        "Inclusão de fotos e vídeos de alta qualidade",
        "Configuração de link para WhatsApp e mensagens instantâneas"
      ]
    },
    {
      title: "2. Otimização Avançada (SEO Local)",
      icon: <BarChart2 className="h-6 w-6 text-blue-600" />,
      items: [
        "Pesquisa de termos de busca na sua região",
        "Otimização de produtos, serviços e posts com keywords locais",
        "Gestão de avaliações: captação e respostas profissionais",
        "Publicação periódica de novidades e promoções",
        "Geotagging e otimização de mídias visuais",
        "Monitoramento de métricas e relatórios mensais"
      ]
    },
    {
      title: "3. Gestão Contínua",
      icon: <RefreshCw className="h-6 w-6 text-blue-600" />,
      items: [
        "Atualização constante de informações",
        "Resposta a novas avaliações e perguntas",
        "Criação de conteúdo regular: posts de eventos e ofertas",
        "Acompanhamento de performance e ajustes estratégicos"
      ]
    }
  ];

  return (
    <section id="servicos" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle 
          title="Nossos Serviços" 
          subtitle="Conheça nossas soluções completas para transformar seu Perfil do Google em um ímã de clientes locais."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {services.map((service, index) => (
            <ServiceItem 
              key={index}
              title={service.title}
              items={service.items}
              icon={service.icon}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;