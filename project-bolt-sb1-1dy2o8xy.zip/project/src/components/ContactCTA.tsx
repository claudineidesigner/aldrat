import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import Button from './Button';
import { Phone, Mail, ArrowRight } from 'lucide-react';

interface FormInputs {
  responsibleName: string;
  companyName: string;
  whatsapp: string;
  email: string;
  location?: string;
  selectedPlan: string;
}

const ContactCTA: React.FC = () => {
  const { register, handleSubmit, setValue, formState: { errors } } = useForm<FormInputs>();
  const [preSelectedPlan, setPreSelectedPlan] = useState<string | undefined>();

  useEffect(() => {
    const getPlanFromHash = () => {
      const hash = window.location.hash;
      const planMatch = hash.match(/plan=([^&]*)/);
      return planMatch ? decodeURIComponent(planMatch[1]) : undefined;
    };

    const updatePlanFromHash = () => {
      const plan = getPlanFromHash();
      setPreSelectedPlan(plan);
      setValue('selectedPlan', plan || '');
    };

    updatePlanFromHash();
    window.addEventListener('hashchange', updatePlanFromHash);

    return () => {
      window.removeEventListener('hashchange', updatePlanFromHash);
    };
  }, [setValue]);

  const formatPhoneNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return value;
  };

  const onSubmit = (data: FormInputs) => {
    const message = `*Olá! Quero otimizar o perfil da minha empresa no Google.*\n\n` +
      `*Nome do Responsável:*\n${data.responsibleName}\n\n` +
      `*Nome da Empresa:*\n${data.companyName}\n\n` +
      `*WhatsApp:*\n${data.whatsapp}\n\n` +
      `*E-mail:*\n${data.email}\n\n` +
      `*Plano Selecionado:*\n${data.selectedPlan}\n\n` +
      (data.location ? `*Localização:*\n${data.location}` : '');

    const whatsappUrl = `https://wa.me/5511970933773?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <section id="contato" className="py-16 bg-blue-600 text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">
            Preencha e comece a ser encontrado!
          </h2>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 bg-white/10 rounded-lg p-6 backdrop-blur-sm">
            <div>
              <label htmlFor="responsibleName" className="block text-sm font-medium mb-2">
                Nome do Responsável *
              </label>
              <input
                {...register("responsibleName", { required: "Campo obrigatório" })}
                type="text"
                className="w-full px-4 py-2 rounded-md bg-white/20 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 text-white placeholder-white/70"
                placeholder="Seu nome completo"
              />
              {errors.responsibleName && (
                <p className="mt-1 text-sm text-red-200">{errors.responsibleName.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="companyName" className="block text-sm font-medium mb-2">
                Nome da Empresa *
              </label>
              <input
                {...register("companyName", { required: "Campo obrigatório" })}
                type="text"
                className="w-full px-4 py-2 rounded-md bg-white/20 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 text-white placeholder-white/70"
                placeholder="Nome da sua empresa"
              />
              {errors.companyName && (
                <p className="mt-1 text-sm text-red-200">{errors.companyName.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="whatsapp" className="block text-sm font-medium mb-2">
                Telefone (WhatsApp) *
              </label>
              <input
                {...register("whatsapp", { 
                  required: "Campo obrigatório",
                  pattern: {
                    value: /^\(\d{2}\) \d{5}-\d{4}$/,
                    message: "Formato: (99) 99999-9999"
                  }
                })}
                type="tel"
                onChange={(e) => {
                  const formatted = formatPhoneNumber(e.target.value);
                  e.target.value = formatted;
                }}
                className="w-full px-4 py-2 rounded-md bg-white/20 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 text-white placeholder-white/70"
                placeholder="(99) 99999-9999"
              />
              {errors.whatsapp && (
                <p className="mt-1 text-sm text-red-200">{errors.whatsapp.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-2">
                E-mail *
              </label>
              <input
                {...register("email", { 
                  required: "Campo obrigatório",
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: "E-mail inválido"
                  }
                })}
                type="email"
                className="w-full px-4 py-2 rounded-md bg-white/20 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 text-white placeholder-white/70"
                placeholder="seu@email.com"
              />
              {errors.email && (
                <p className="mt-1 text-sm text-red-200">{errors.email.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="location" className="block text-sm font-medium mb-2">
                Cidade/Estado (Opcional)
              </label>
              <input
                {...register("location")}
                type="text"
                className="w-full px-4 py-2 rounded-md bg-white/20 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 text-white placeholder-white/70"
                placeholder="São Paulo, SP"
              />
            </div>

            <div>
              <label htmlFor="selectedPlan" className="block text-sm font-medium mb-2">
                Plano Selecionado *
              </label>
              {preSelectedPlan ? (
                <div className="w-full px-4 py-2 rounded-md bg-blue-700 border border-white/30 text-white">
                  {preSelectedPlan}
                </div>
              ) : (
                <select
                  {...register("selectedPlan", { required: "Por favor, selecione um plano" })}
                  className="w-full px-4 py-2 rounded-md bg-blue-700 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 text-white [&>option]:bg-blue-700 [&>option]:text-white"
                >
                  <option value="">Selecione um plano</option>
                  <option value="Essencial">Essencial</option>
                  <option value="Pro">Pro</option>
                  <option value="Premium">Premium</option>
                </select>
              )}
              {errors.selectedPlan && (
                <p className="mt-1 text-sm text-red-200">{errors.selectedPlan.message}</p>
              )}
            </div>

            <Button 
              variant="secondary" 
              className="w-full justify-center"
              type="submit"
            >
              Quero meu Perfil Otimizado!
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </form>

          <div className="mt-12 flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-10">
            <div className="flex items-center">
              <Phone className="h-6 w-6 mr-2" />
              <span className="text-lg">(11) 97093-3773</span>
            </div>
            <div className="flex items-center">
              <Mail className="h-6 w-6 mr-2" />
              <span className="text-lg">contato@aldrat.com</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactCTA;