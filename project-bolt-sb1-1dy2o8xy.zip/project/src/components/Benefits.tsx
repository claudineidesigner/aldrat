import React from 'react';
import { MapPin, Search, Star, Phone } from 'lucide-react';
import SectionTitle from './SectionTitle';

interface BenefitProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const BenefitCard: React.FC<BenefitProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 flex flex-col items-start">
      <div className="bg-blue-100 p-3 rounded-lg mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3 text-gray-900">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const Benefits: React.FC = () => {
  const benefits = [
    {
      icon: <MapPin className="h-6 w-6 text-blue-600" />,
      title: "Domine o Mapa Local (Antes dos Outros):",
      description: "Imagine seu negócio em destaque no Google Maps e no Pacote Local toda vez que alguém procurar o que você oferece. É a sua chance de ser a primeira escolha, capturando clientes que seus concorrentes nem veem."
    },
    {
      icon: <Star className="h-6 w-6 text-blue-600" />,
      title: "Construa Confiança Inabalável (e Atraia Mais):",
      description: "No Google, confiança é tudo. Avaliações estelares e um perfil ativo são seu passaporte para a credibilidade. É a oportunidade de mostrar que você é a autoridade local, atraindo clientes que buscam qualidade e segurança."
    },
    {
      icon: <Phone className="h-6 w-6 text-blue-600" />,
      title: "Conecte-se Imediatamente (Venda Agora):",
      description: "Clientes decidem rápido. Com um clique, eles podem ligar, traçar rotas ou enviar mensagens. Esta é a oportunidade de converter o interesse instantâneo em visitas e vendas reais, hoje mesmo."
    },
    {
      icon: <Search className="h-6 w-6 text-blue-600" />,
      title: "Transforme o Grátis em Lucro Real (Com Nossa Ajuda):",
      description: "O Google oferece a ferramenta, nós entregamos a estratégia vencedora. É a oportunidade de destravar o potencial máximo de um recurso gratuito e transformá-lo em um fluxo constante de clientes, com resultados que você vê no caixa."
    }
  ];

  return (
    <section id="beneficios" className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle 
          title="Seus Clientes Estão no Google. Quem Eles Estão Encontrando?" 
          subtitle="Descubra a oportunidade escondida no Google Meu Negócio e transforme buscas locais em sua maior fonte de receita."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
          {benefits.map((benefit, index) => (
            <BenefitCard 
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;