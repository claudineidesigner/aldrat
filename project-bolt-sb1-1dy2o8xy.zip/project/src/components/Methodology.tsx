import React from 'react';
import SectionTitle from './SectionTitle';
import { FileSearch, ClipboardList, Zap, BarChart } from 'lucide-react';

interface MethodStepProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  step: number;
}

const MethodStep: React.FC<MethodStepProps> = ({ icon, title, description, step }) => {
  return (
    <div className="relative">
      <div className="flex items-start">
        <div className="mr-6 relative">
          <div className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 text-blue-600">
            {icon}
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
            {step}
          </div>
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-2 text-gray-900">{title}</h3>
          <p className="text-gray-600">{description}</p>
        </div>
      </div>
      {step < 4 && (
        <div className="hidden md:block absolute h-16 w-1 bg-blue-100 left-8 top-full"></div>
      )}
    </div>
  );
};

const Methodology: React.FC = () => {
  const steps = [
    {
      icon: <FileSearch className="h-6 w-6" />,
      title: "Diagnóstico Gratuito",
      description: "Identificamos onde você está e onde pode chegar: uma auditoria completa de gaps e oportunidades.",
      step: 1
    },
    {
      icon: <ClipboardList className="h-6 w-6" />,
      title: "Plano Personalizado",
      description: "Definimos a estratégia, as ações e as metas de visibilidade para o seu negócio crescer.",
      step: 2
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Execução Ágil",
      description: "Implementamos tudo – configuração, otimização e posts iniciais – em tempo recorde para você ver resultados logo.",
      step: 3
    },
    {
      icon: <BarChart className="h-6 w-6" />,
      title: "Monitoramento e Ajustes",
      description: "Acompanhamos os números e fazemos os ajustes finos para garantir que você continue crescendo mês a mês.",
      step: 4
    }
  ];

  return (
    <section id="metodologia" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle 
          title="Como Levamos Você ao Topo: Nosso Método" 
          subtitle="Entenda nosso processo passo a passo, focado em entregar visibilidade e clientes de forma eficiente."
        />
        
        <div className="mt-12 md:mt-16 flex flex-col md:flex-row space-y-12 md:space-y-0 md:space-x-8 lg:space-x-16 justify-center">
          <div className="space-y-16">
            {steps.map((step, index) => (
              <MethodStep 
                key={index}
                icon={step.icon}
                title={step.title}
                description={step.description}
                step={step.step}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Methodology;