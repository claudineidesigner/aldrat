import React from 'react';
import SectionTitle from './SectionTitle';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle 
          title="Prova Social" 
          subtitle="O que nossos clientes dizem sobre nossos serviços"
        />
        
        <div className="mt-12 max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl shadow-md p-8 md:p-10 relative">
            <Quote className="absolute text-blue-200 h-24 w-24 -top-6 -left-6 opacity-40" />
            
            <div className="relative z-10">
              <div className="flex mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="h-6 w-6 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <p className="text-lg md:text-xl text-gray-700 italic mb-6">
                "Em poucos dias o meu novo perfil já estava classificado em primeiro lugar para pesquisas como: Encomenda de bolo de aniversário no Parque Boa Esperança. 🧡"
              </p>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-200 rounded-full mr-4 flex items-center justify-center text-blue-600 font-bold">
                  JS
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Cristina Silva</h4>
                  <p className="text-gray-600">Confeitaria Bheli</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;