import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <div className="flex items-center">
          <img 
            src="/Aldrat_Marketing_LogoTipo_Perfil_da_Empresa.png" 
            alt="Aldrat Marketing" 
            className="h-8 w-auto mr-2"
          />
          <span className="text-xl font-bold text-gray-900">Aldrat.com</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#beneficios" className="text-gray-700 hover:text-blue-600 transition-colors">Benefícios</a>
          <a href="#servicos" className="text-gray-700 hover:text-blue-600 transition-colors">Serviços</a>
          <a href="#pacotes" className="text-gray-700 hover:text-blue-600 transition-colors">Pacotes</a>
          <a href="#metodologia" className="text-gray-700 hover:text-blue-600 transition-colors">Metodologia</a>
          <a href="#contato" className="text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md transition-colors">
            Contato
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          {isOpen ? (
            <X 
              className="h-6 w-6 text-gray-700" 
              onClick={() => setIsOpen(false)} 
            />
          ) : (
            <Menu 
              className="h-6 w-6 text-gray-700" 
              onClick={() => setIsOpen(true)} 
            />
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white shadow-lg absolute top-full left-0 right-0">
          <div className="flex flex-col space-y-4 px-4 py-6">
            <a 
              href="#beneficios" 
              className="text-gray-700 hover:text-blue-600 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Benefícios
            </a>
            <a 
              href="#servicos" 
              className="text-gray-700 hover:text-blue-600 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Serviços
            </a>
            <a 
              href="#pacotes" 
              className="text-gray-700 hover:text-blue-600 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Pacotes
            </a>
            <a 
              href="#metodologia" 
              className="text-gray-700 hover:text-blue-600 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Metodologia
            </a>
            <a 
              href="#contato" 
              className="text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md transition-colors inline-block"
              onClick={() => setIsOpen(false)}
            >
              Contato
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;