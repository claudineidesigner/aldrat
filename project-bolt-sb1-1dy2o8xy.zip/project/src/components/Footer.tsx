import React from 'react';
import { MapPin, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-gray-300 pt-12 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <MapPin className="h-6 w-6 text-blue-500 mr-2" />
              <span className="text-xl font-bold text-white">Aldrat.com</span>
            </div>
            <p className="mb-4">
              Especialistas em marketing local e otimização de presença digital para negócios de todos os tamanhos.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li><a href="#beneficios" className="hover:text-white transition-colors">Benefícios</a></li>
              <li><a href="#servicos" className="hover:text-white transition-colors">Serviços</a></li>
              <li><a href="#pacotes" className="hover:text-white transition-colors">Pacotes</a></li>
              <li><a href="#metodologia" className="hover:text-white transition-colors">Metodologia</a></li>
              <li><a href="#contato" className="hover:text-white transition-colors">Contato</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Serviços</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white transition-colors">Google Meu Negócio</a></li>
              <li><a href="#" className="hover:text-white transition-colors">SEO Local</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Marketing Digital</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Consultoria</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Gestão de Mídias Sociais</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Contato</h4>
            <ul className="space-y-2">
              <li>Prq Boa Esperança, São Paulo - SP, 08341-370</li>
              <li>contato@aldrat.com</li>
              <li>(11) 97093-3773</li>
            </ul>
          </div>
        </div>
        
        <div className="pt-6 border-t border-gray-800 text-center text-sm">
          <p>&copy; {currentYear} Aldrat.com | Marketing Digital Para Negócios Locais. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;